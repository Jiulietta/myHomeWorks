#Выведите на экран надпись To be or not to be на разных
#строках.

print("    To be"+"\n"+"    or not"+"\n"+"    to be")



