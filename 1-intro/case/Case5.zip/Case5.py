#Выведите на экран надпись «Life is what happens when
#you're busy making other plans» John Lennon на разных
#строках.

print("Life is what happens")
print("    when")
print("        you’re busy making other plans")
print("John Lennon")